#ifndef __CODE_IDE_SUPPORT_H__
#define __CODE_IDE_SUPPORT_H__

// define 1 to open Cocos Code IDE support, 0 to disable
#define CC_CODE_IDE_DEBUG_SUPPORT 1

#endif /* __CODE_IDE_SUPPORT_H__ */
