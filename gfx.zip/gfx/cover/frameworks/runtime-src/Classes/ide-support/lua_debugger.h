
/* lua_debugger.h.h */

#ifndef __LUA_MODULES_049C000C96FE547176CCBB7690BA01B6_H_
#define __LUA_MODULES_049C000C96FE547176CCBB7690BA01B6_H_

#if __cplusplus
extern "C" {
#endif

#include "lua.h"

void luaopen_lua_debugger(lua_State* L);

/*
int luaopen_lua_m_debugger(lua_State* L);
*/

#if __cplusplus
}
#endif

#endif /* __LUA_MODULES_049C000C96FE547176CCBB7690BA01B6_H_ */
